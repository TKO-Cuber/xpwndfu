require "extend/ENV/std"
require "extend/os/mac/extend/ENV/std" if OS.mac?
require "extend/os/linux/extend/ENV/std" if OS.linux?
