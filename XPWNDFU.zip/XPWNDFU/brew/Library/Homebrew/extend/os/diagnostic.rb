require "diagnostic"
require "extend/os/mac/diagnostic" if OS.mac?
