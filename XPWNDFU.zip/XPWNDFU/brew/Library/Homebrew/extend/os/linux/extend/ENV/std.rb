module Stdenv
  # needed by XorgRequirement
  def x11; end
end
