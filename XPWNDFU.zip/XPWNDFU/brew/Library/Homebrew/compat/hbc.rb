require "compat/hbc/cask_loader"
require "compat/hbc/cli/update"
