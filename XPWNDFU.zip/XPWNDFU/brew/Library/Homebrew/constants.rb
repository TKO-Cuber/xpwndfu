# RuboCop version used for `brew style` and `brew cask style`
HOMEBREW_RUBOCOP_VERSION = "0.47.1".freeze
HOMEBREW_RUBOCOP_CASK_VERSION = "~> 0.11.0".freeze # has to be updated when RuboCop version changes
