require "hbc/artifact/moved"

module Hbc
  module Artifact
    class App < Moved
    end
  end
end
