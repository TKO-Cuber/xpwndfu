require "hbc/artifact/abstract_flight_block"

module Hbc
  module Artifact
    class PostflightBlock < AbstractFlightBlock
    end
  end
end
