require "hbc/artifact/moved"

module Hbc
  module Artifact
    class Service < Moved
    end
  end
end
