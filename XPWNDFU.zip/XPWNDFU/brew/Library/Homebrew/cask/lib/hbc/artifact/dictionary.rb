require "hbc/artifact/moved"

module Hbc
  module Artifact
    class Dictionary < Moved
    end
  end
end
