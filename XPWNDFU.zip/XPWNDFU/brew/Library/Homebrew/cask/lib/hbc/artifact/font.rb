require "hbc/artifact/moved"

module Hbc
  module Artifact
    class Font < Moved
    end
  end
end
