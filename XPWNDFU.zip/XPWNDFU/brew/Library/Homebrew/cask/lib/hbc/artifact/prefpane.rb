require "hbc/artifact/moved"

module Hbc
  module Artifact
    class Prefpane < Moved
      def self.artifact_english_name
        "Preference Pane"
      end
    end
  end
end
