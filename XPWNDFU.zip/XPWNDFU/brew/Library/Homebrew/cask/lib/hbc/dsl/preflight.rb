module Hbc
  class DSL
    class Preflight < Base
      include Staged
    end
  end
end
