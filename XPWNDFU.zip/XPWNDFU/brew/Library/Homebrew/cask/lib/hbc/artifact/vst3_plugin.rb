require "hbc/artifact/moved"

module Hbc
  module Artifact
    class Vst3Plugin < Moved
    end
  end
end
